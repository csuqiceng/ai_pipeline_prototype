"use client";

import { useState } from "react";
import { useRobot } from "@/lib/robot-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RefreshCw, Mic, Trash2, Play } from "lucide-react";

export function EngineerRunPage() {
  const {
    snapshot,
    templates,
    addMessage,
    connectController,
    executionState,
  } = useRobot();

  const [controllerIp, setControllerIp] = useState("192.168.1.11");
  const [controllerType, setControllerType] = useState("real");
  const [protocol, setProtocol] = useState("modbus_v22");
  const [nlpInput, setNlpInput] = useState(
    "例如：执行流程11 / 回零 / 启动 / 把机械手移动到位置A"
  );
  const [useOnlineAI, setUseOnlineAI] = useState(true);
  const [parseResult, setParseResult] = useState("");
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    await connectController(controllerIp);
    setIsConnecting(false);
  };

  const handleParseText = () => {
    // 模拟解析
    const matchedTemplate = templates.find(
      (t) =>
        nlpInput.includes(t.queryKey) ||
        t.keywords.split(" ").some((k) => nlpInput.includes(k))
    );

    if (matchedTemplate) {
      setParseResult(
        JSON.stringify(
          {
            matched: true,
            template: matchedTemplate.queryKey,
            func_id: matchedTemplate.funcNum,
            params: matchedTemplate.params,
          },
          null,
          2
        )
      );
      addMessage("system", `已匹配指令：${matchedTemplate.funcName}`, "plan");
    } else {
      setParseResult(
        JSON.stringify(
          {
            matched: false,
            message: "未匹配到指令模板，将调用AI解析",
          },
          null,
          2
        )
      );
      addMessage("system", "未匹配到指令，需要AI解析", "receipt");
    }
  };

  return (
    <div className="flex flex-col h-full gap-4 overflow-auto">
      {/* 连接与反馈区域 */}
      <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
        <h3 className="text-sm font-medium text-muted-foreground mb-3 border-b border-sidebar pb-1">
          连接与反馈
        </h3>
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <Label className="text-sm whitespace-nowrap">控制器地址:</Label>
            <Input
              value={controllerIp}
              onChange={(e) => setControllerIp(e.target.value)}
              className="w-32 h-8 text-sm"
            />
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-sm whitespace-nowrap">控制器类型:</Label>
            <Select value={controllerType} onValueChange={setControllerType}>
              <SelectTrigger className="w-28 h-8 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="real">真实控制器</SelectItem>
                <SelectItem value="virtual">模拟控制器</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-sm whitespace-nowrap">协议:</Label>
            <Select value={protocol} onValueChange={setProtocol}>
              <SelectTrigger className="w-36 h-8 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="modbus_v22">Modbus TCP (V2.2)</SelectItem>
                <SelectItem value="modbus_v21">Modbus TCP (V2.1)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="whitespace-nowrap">连接状态:</span>
            <span
              className={
                snapshot.connectionState === "online"
                  ? "text-[#137A3D]"
                  : "text-destructive"
              }
            >
              {snapshot.connectionState === "online" ? "已连接" : "连接失败"}
            </span>
          </div>
          <Button
            size="sm"
            onClick={handleConnect}
            disabled={isConnecting}
            className="bg-sidebar hover:bg-sidebar/90 text-sidebar-foreground"
          >
            检测连接
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="border-sidebar text-sidebar"
          >
            读取反馈
          </Button>
        </div>
      </div>

      {/* 执行模式选项卡 */}
      <Tabs defaultValue="nlp" className="flex-1">
        <TabsList className="bg-muted">
          <TabsTrigger value="single">单次执行</TabsTrigger>
          <TabsTrigger value="flow">流程执行</TabsTrigger>
          <TabsTrigger value="nlp">自然语言执行</TabsTrigger>
        </TabsList>

        {/* 单次执行 */}
        <TabsContent value="single" className="mt-4">
          <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
            <h3 className="text-sm font-medium text-muted-foreground mb-3">
              固定指令执行
            </h3>
            <div className="grid grid-cols-4 gap-2">
              {templates.slice(0, 8).map((t) => (
                <Button
                  key={t.queryKey}
                  variant="outline"
                  size="sm"
                  className="justify-start text-xs"
                  onClick={() => addMessage("user", t.queryKey, "input")}
                >
                  {t.queryKey}
                </Button>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* 流程执行 */}
        <TabsContent value="flow" className="mt-4">
          <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
            <h3 className="text-sm font-medium text-muted-foreground mb-3">
              流程选择与执行
            </h3>
            <div className="flex items-center gap-4">
              <Select defaultValue="flow1">
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="选择流程" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="flow1">流程1: 初始化流程</SelectItem>
                  <SelectItem value="flow2">流程2: 取料流程</SelectItem>
                  <SelectItem value="flow3">流程3: 放料流程</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-primary hover:bg-primary/90">
                开始执行
              </Button>
              <Button variant="outline">单步执行</Button>
              <Button variant="destructive">停止</Button>
            </div>
          </div>
        </TabsContent>

        {/* 自然语言执行 */}
        <TabsContent value="nlp" className="mt-4 flex-1">
          <div className="grid grid-cols-2 gap-4 h-full">
            {/* 左侧：自然语言输入 */}
            <div className="p-4 border-2 border-sidebar rounded-lg bg-card flex flex-col">
              <h3 className="text-sm font-medium text-muted-foreground mb-3 border-b border-sidebar pb-1">
                自然语言执行
              </h3>
              <div className="flex items-center gap-4 mb-3">
                <span className="text-sm">输入文本:</span>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="onlineAI"
                    checked={useOnlineAI}
                    onCheckedChange={(checked) =>
                      setUseOnlineAI(checked as boolean)
                    }
                  />
                  <Label htmlFor="onlineAI" className="text-sm">
                    在线AI解析
                  </Label>
                </div>
                <span className="text-sm">麦克风:</span>
                <Select defaultValue="default">
                  <SelectTrigger className="w-40 h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">系统默认麦克风</SelectItem>
                  </SelectContent>
                </Select>
                <Button size="sm" variant="outline">
                  <RefreshCw className="w-4 h-4 mr-1" />
                  刷新设备
                </Button>
              </div>
              <Textarea
                value={nlpInput}
                onChange={(e) => setNlpInput(e.target.value)}
                className="flex-1 min-h-[120px] resize-none"
                placeholder="输入自然语言指令..."
              />
              <div className="flex gap-2 mt-3">
                <Button
                  variant="outline"
                  onClick={handleParseText}
                  className="flex-1"
                >
                  解析文本
                </Button>
                <Button variant="outline" className="flex-1">
                  <Mic className="w-4 h-4 mr-2" />
                  开始录音
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setNlpInput("")}
                  className="flex-1"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  清空
                </Button>
                <Button className="flex-1 bg-sidebar hover:bg-sidebar/90 text-sidebar-foreground">
                  <Play className="w-4 h-4 mr-2" />
                  执行
                </Button>
              </div>
            </div>

            {/* 右侧：解析结果 */}
            <div className="p-4 border-2 border-sidebar rounded-lg bg-card flex flex-col">
              <h3 className="text-sm font-medium text-muted-foreground mb-3 border-b border-sidebar pb-1">
                解析结果
              </h3>
              <pre className="flex-1 p-3 bg-muted rounded text-xs overflow-auto font-mono">
                {parseResult || "等待解析..."}
              </pre>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* 底部状态区域 */}
      <div className="grid grid-cols-3 gap-4">
        {/* 机械手状态 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-3 border-b border-sidebar pb-1">
            机械手状态
          </h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>X:</div>
            <div className="text-right font-mono">
              {snapshot.dpos[0]?.toFixed(1)}
            </div>
            <div>Y:</div>
            <div className="text-right font-mono">
              {snapshot.dpos[1]?.toFixed(1)}
            </div>
            <div>Z:</div>
            <div className="text-right font-mono">
              {snapshot.dpos[2]?.toFixed(1)}
            </div>
            <div>RX / RY / RZ:</div>
            <div className="text-right font-mono">
              {snapshot.dpos[3]?.toFixed(1)} / {snapshot.dpos[4]?.toFixed(1)} /{" "}
              {snapshot.dpos[5]?.toFixed(1)}
            </div>
            <div>速度 / 加速度:</div>
            <div className="text-right font-mono">{snapshot.speed}% / 40%</div>
            <div>夹爪使能:</div>
            <div className="text-right font-mono">0</div>
            <div>夹爪刹车:</div>
            <div className="text-right font-mono">0</div>
            <div>伺服使能:</div>
            <div className="text-right font-mono">0</div>
            <div>实时状态:</div>
            <div className="text-right font-mono">空闲</div>
            <div>监控任务ID:</div>
            <div className="text-right font-mono">-</div>
            <div>运动进度:</div>
            <div className="text-right font-mono">0%</div>
            <div>命令回显:</div>
            <div className="text-right font-mono">-</div>
            <div>执行触发:</div>
            <div className="text-right font-mono">0</div>
          </div>
        </div>

        {/* 执行摘要 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-3 border-b border-sidebar pb-1">
            执行摘要
          </h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>当前模式:</div>
            <div className="text-right font-mono">自动</div>
            <div>忙闲状态:</div>
            <div className="text-right font-mono">空闲</div>
            <div>执行结果:</div>
            <div className="text-right font-mono">
              {executionState?.status === "completed" ? "成功" : "0"}
            </div>
            <div>报警码:</div>
            <div className="text-right font-mono">ERR_000</div>
            <div>系统说明:</div>
            <div className="text-right font-mono">系统正常</div>
            <div>IO状态位:</div>
            <div className="text-right font-mono">0</div>
            <div>当前任务ID:</div>
            <div className="text-right font-mono">
              {executionState?.taskId || 1001}
            </div>
          </div>
        </div>

        {/* 最近执行记录 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-3 border-b border-sidebar pb-1">
            最近执行记录
          </h3>
          <div className="overflow-auto max-h-[200px]">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0">
                <tr>
                  <th className="p-1 text-left">任务ID</th>
                  <th className="p-1 text-left">指令码</th>
                  <th className="p-1 text-left">名称</th>
                  <th className="p-1 text-left">指令类型</th>
                  <th className="p-1 text-left">结果</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-border">
                  <td className="p-1">1001</td>
                  <td className="p-1">1001</td>
                  <td className="p-1">-</td>
                  <td className="p-1">参数型指令</td>
                  <td className="p-1 text-[#A96800]">待执行</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
