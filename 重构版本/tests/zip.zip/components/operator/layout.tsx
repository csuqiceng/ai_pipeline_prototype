"use client";

import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { StatusBar } from "./status-bar";
import { ChatArea } from "./chat-area";
import { SidePanel } from "./side-panel";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  MessageSquare,
  Shield,
  Activity,
  AlertTriangle,
  LayoutDashboard,
  LogOut,
  Settings,
  Wrench,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type OperatorScene =
  | "chat"
  | "precheck"
  | "monitor"
  | "alarm"
  | "status";

interface OperatorLayoutProps {
  onSwitchToEngineer?: () => void;
}

export function OperatorLayout({ onSwitchToEngineer }: OperatorLayoutProps) {
  const { user, logout } = useAuth();
  const [activeScene, setActiveScene] = useState<OperatorScene>("chat");

  const scenes: { id: OperatorScene; label: string; icon: React.ReactNode }[] =
    [
      {
        id: "chat",
        label: "智能对话",
        icon: <MessageSquare className="w-4 h-4" />,
      },
      {
        id: "precheck",
        label: "安全预检",
        icon: <Shield className="w-4 h-4" />,
      },
      {
        id: "monitor",
        label: "执行监控",
        icon: <Activity className="w-4 h-4" />,
      },
      {
        id: "alarm",
        label: "报警处理",
        icon: <AlertTriangle className="w-4 h-4" />,
      },
      {
        id: "status",
        label: "完整状态",
        icon: <LayoutDashboard className="w-4 h-4" />,
      },
    ];

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* 常驻状态栏 */}
      <StatusBar />

      {/* 主内容区 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧场景导航 */}
        <nav className="w-32 bg-card border-r border-border flex flex-col py-4">
          {scenes.map((scene) => (
            <button
              key={scene.id}
              onClick={() => setActiveScene(scene.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-3 text-sm transition-colors",
                activeScene === scene.id
                  ? "bg-sidebar/10 text-sidebar border-r-2 border-sidebar font-medium"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              {scene.icon}
              {scene.label}
            </button>
          ))}

          <div className="flex-1" />

          {/* 用户菜单 */}
          <div className="px-4 pt-4 border-t border-border">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-xs h-8"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  设置
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-48">
                <div className="px-2 py-1.5 text-sm font-medium text-foreground">
                  {user?.displayName}
                </div>
                <DropdownMenuSeparator />
                {onSwitchToEngineer && (
                  <DropdownMenuItem onClick={onSwitchToEngineer}>
                    <Wrench className="w-4 h-4 mr-2" />
                    切换到工程师页面
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={logout}
                  className="text-destructive"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  退出登录
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </nav>

        {/* 主场景区域 */}
        <main className="flex-1 flex overflow-hidden">
          {activeScene === "chat" && <ChatArea />}
          {activeScene === "precheck" && <PrecheckScene />}
          {activeScene === "monitor" && <MonitorScene />}
          {activeScene === "alarm" && <AlarmScene />}
          {activeScene === "status" && <StatusScene />}
        </main>

        {/* 右侧状态面板 */}
        <SidePanel />
      </div>
    </div>
  );
}

// 安全预检场景
function PrecheckScene() {
  return (
    <div className="flex-1 p-6 overflow-auto">
      <h2 className="text-xl font-bold mb-4">安全预检</h2>
      <div className="grid gap-4">
        <div className="p-4 bg-card border border-border rounded-lg">
          <h3 className="font-medium mb-2 flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#137A3D]" />
            状态检查
          </h3>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span>无急停</span>
              <span className="text-[#137A3D]">通过</span>
            </div>
            <div className="flex items-center justify-between">
              <span>无报警</span>
              <span className="text-[#137A3D]">通过</span>
            </div>
            <div className="flex items-center justify-between">
              <span>未暂停</span>
              <span className="text-[#137A3D]">通过</span>
            </div>
            <div className="flex items-center justify-between">
              <span>控制器在线</span>
              <span className="text-[#A96800]">待检</span>
            </div>
          </div>
        </div>
        <div className="p-4 bg-card border border-border rounded-lg">
          <h3 className="font-medium mb-2">参数检查</h3>
          <p className="text-sm text-muted-foreground">
            请先发送指令以进行参数预检
          </p>
        </div>
      </div>
    </div>
  );
}

// 执行监控场景
function MonitorScene() {
  return (
    <div className="flex-1 p-6 overflow-auto">
      <h2 className="text-xl font-bold mb-4">执行监控</h2>
      <div className="p-4 bg-card border border-border rounded-lg">
        <p className="text-muted-foreground">当前无执行任务</p>
      </div>
    </div>
  );
}

// 报警处理场景
function AlarmScene() {
  return (
    <div className="flex-1 p-6 overflow-auto">
      <h2 className="text-xl font-bold mb-4">报警处理</h2>
      <div className="p-4 bg-[#137A3D]/10 border border-[#137A3D] rounded-lg">
        <div className="flex items-center gap-2 text-[#137A3D]">
          <Shield className="w-5 h-5" />
          <span className="font-medium">系统正常，无报警</span>
        </div>
      </div>
    </div>
  );
}

// 完整状态场景
function StatusScene() {
  return (
    <div className="flex-1 p-6 overflow-auto">
      <h2 className="text-xl font-bold mb-4">完整状态</h2>
      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-card border border-border rounded-lg">
          <h3 className="font-medium mb-3">设备基础状态</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">系统状态</span>
              <span>空闲</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">当前函数</span>
              <span>-</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">急停状态</span>
              <span className="text-[#137A3D]">正常</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">暂停状态</span>
              <span className="text-[#137A3D]">未暂停</span>
            </div>
          </div>
        </div>
        <div className="p-4 bg-card border border-border rounded-lg">
          <h3 className="font-medium mb-3">安全边界</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">R范围</span>
              <span>200 ~ 1500 mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Z范围</span>
              <span>100 ~ 1200 mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">当前R</span>
              <span>1250.0 mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">当前Z</span>
              <span>860.0 mm</span>
            </div>
          </div>
        </div>
        <div className="p-4 bg-card border border-border rounded-lg">
          <h3 className="font-medium mb-3">运动极限</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">最大速度</span>
              <span>80%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">最大加速度</span>
              <span>100%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">当前速度</span>
              <span>30%</span>
            </div>
          </div>
        </div>
        <div className="p-4 bg-card border border-border rounded-lg">
          <h3 className="font-medium mb-3">通讯诊断</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Modbus TCP</span>
              <span className="text-[#A96800]">待连接</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">EtherCAT</span>
              <span className="text-[#137A3D]">正常</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">实时反馈</span>
              <span className="text-[#A96800]">离线</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
