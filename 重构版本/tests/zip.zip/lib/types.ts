// 用户角色类型
export type UserRole = "engineer" | "operator";

// 用户信息
export interface User {
  id: string;
  username: string;
  role: UserRole;
  displayName: string;
}

// 系统状态
export type SystemState =
  | "running"
  | "idle"
  | "estop"
  | "pause"
  | "alarm"
  | "offline";

// 机械手状态快照
export interface RobotSnapshot {
  systemState: SystemState;
  connectionState: "online" | "offline" | "connecting";
  estop: boolean;
  pause: boolean;
  alarmCode: number;
  alarmText: string;
  currentFunc: number;
  dpos: number[]; // 6轴指令位置
  mpos: number[]; // 6轴编码器位置
  rCurrent: number;
  zCurrent: number;
  speed: number;
  taskId: number;
}

// 对话事件
export interface ConversationEvent {
  eventId: string;
  time: Date;
  role: "user" | "system" | "assistant";
  eventType:
    | "input"
    | "receipt"
    | "status"
    | "plan"
    | "precheck"
    | "confirm"
    | "execute"
    | "alarm";
  text: string;
  payload?: Record<string, unknown>;
}

// 动作计划
export interface ActionPlan {
  planId: string;
  source: "rule" | "deepseek" | "button";
  actionType: "template" | "flow" | "system" | "query";
  target: string;
  params: Record<string, unknown>;
  safetyLevel: "normal" | "confirm" | "forbidden";
  precheckStatus: "pending" | "checking" | "passed" | "risk" | "failed";
  confirmRequired: boolean;
}

// 预检结果
export interface PrecheckResult {
  planId: string;
  status: "passed" | "risk" | "failed";
  checks: {
    name: string;
    status: "passed" | "risk" | "failed";
    detail: string;
  }[];
  riskSummary?: string;
  suggestion?: string;
}

// 执行状态
export interface ExecutionState {
  taskId: number;
  planId: string;
  status: "pending" | "executing" | "completed" | "failed" | "cancelled";
  progressPct: number;
  progressIsEstimated: boolean;
  currentStep: number;
  totalSteps: number;
  result?: string;
}

// 指令模板
export interface CommandTemplate {
  queryKey: string;
  funcNum: number;
  funcName: string;
  keywords: string;
  safetyLevel: number;
  description: string;
  params: Record<string, unknown>;
  writes: { startVr: number; values: number[] }[];
}

// 日志记录
export interface LogEntry {
  id: number;
  time: string;
  category: string;
  operation: string;
  result: "success" | "failed";
  detail: string;
}

// 流程定义
export interface FlowDefinition {
  id: string;
  name: string;
  steps: {
    stepId: number;
    templateKey: string;
    description: string;
  }[];
}
