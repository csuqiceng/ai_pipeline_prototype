"use client";

import {
  createContext,
  useContext,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import type { User, UserRole } from "./types";

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  switchRole: (role: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// 模拟用户数据库（实际项目中应该连接真实后端）
const MOCK_USERS: Record<string, { password: string; user: User }> = {
  engineer: {
    password: "engineer123",
    user: {
      id: "1",
      username: "engineer",
      role: "engineer",
      displayName: "工程师账号",
    },
  },
  operator: {
    password: "operator123",
    user: {
      id: "2",
      username: "operator",
      role: "operator",
      displayName: "操作员账号",
    },
  },
  admin: {
    password: "admin123",
    user: {
      id: "3",
      username: "admin",
      role: "engineer",
      displayName: "管理员",
    },
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback(
    async (username: string, password: string): Promise<boolean> => {
      // 模拟登录验证
      const userData = MOCK_USERS[username];
      if (userData && userData.password === password) {
        setUser(userData.user);
        return true;
      }
      return false;
    },
    []
  );

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const switchRole = useCallback((role: UserRole) => {
    setUser((prev) =>
      prev
        ? {
            ...prev,
            role,
            displayName: role === "engineer" ? "工程师账号" : "操作员账号",
          }
        : null
    );
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        switchRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
