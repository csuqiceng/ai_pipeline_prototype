"use client";

import { useState } from "react";
import { AuthProvider, useAuth } from "@/lib/auth-context";
import { RobotProvider } from "@/lib/robot-context";
import { LoginForm } from "@/components/login-form";
import { EngineerLayout } from "@/components/engineer/layout";
import { OperatorLayout } from "@/components/operator/layout";

function AppContent() {
  const { user, isAuthenticated, switchRole } = useAuth();
  const [currentView, setCurrentView] = useState<"engineer" | "operator" | null>(null);

  // 如果未登录，显示登录页
  if (!isAuthenticated) {
    return (
      <LoginForm
        onSuccess={() => {
          // 登录成功后根据角色设置默认视图
          // 这里会在下一次渲染时由 user.role 决定
        }}
      />
    );
  }

  // 确定当前视图
  const view = currentView || (user?.role === "engineer" ? "engineer" : "operator");

  const handleSwitchToEngineer = () => {
    switchRole("engineer");
    setCurrentView("engineer");
  };

  const handleSwitchToOperator = () => {
    switchRole("operator");
    setCurrentView("operator");
  };

  // 根据视图显示对应页面
  if (view === "engineer") {
    return <EngineerLayout onSwitchToOperator={handleSwitchToOperator} />;
  }

  return <OperatorLayout onSwitchToEngineer={handleSwitchToEngineer} />;
}

export default function RobotControlApp() {
  return (
    <AuthProvider>
      <RobotProvider>
        <AppContent />
      </RobotProvider>
    </AuthProvider>
  );
}
