"use client";

import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  type ReactNode,
} from "react";
import type {
  RobotSnapshot,
  ConversationEvent,
  ActionPlan,
  ExecutionState,
  CommandTemplate,
  LogEntry,
} from "./types";

// 模拟指令模板数据
const MOCK_TEMPLATES: CommandTemplate[] = [
  {
    queryKey: "IO0关闭",
    funcNum: 120,
    funcName: "Func120 IO控制",
    keywords: "IO0 关闭 输出 夹爪",
    safetyLevel: 5,
    description: "Func120 设置 Y0 输出为 OFF",
    params: { io_no: 0, io_action: 0 },
    writes: [
      { startVr: 0, values: [120.0] },
      { startVr: 2, values: [0.0] },
      { startVr: 4, values: [0.0] },
      { startVr: 32, values: [1.0] },
    ],
  },
  {
    queryKey: "IO0打开",
    funcNum: 120,
    funcName: "Func120 IO控制",
    keywords: "IO0 打开 输出 夹爪",
    safetyLevel: 5,
    description: "Func120 设置 Y0 输出为 ON",
    params: { io_no: 0, io_action: 1 },
    writes: [
      { startVr: 0, values: [120.0] },
      { startVr: 2, values: [0.0] },
      { startVr: 4, values: [1.0] },
      { startVr: 32, values: [1.0] },
    ],
  },
  {
    queryKey: "J1到10度",
    funcNum: 106,
    funcName: "Func106 单轴点动",
    keywords: "J1 10度 关节",
    safetyLevel: 3,
    description: "J1轴移动到10度",
    params: { axis_no: 0, pos_val: 10.0 },
    writes: [{ startVr: 0, values: [106.0] }],
  },
  {
    queryKey: "J2回正",
    funcNum: 106,
    funcName: "Func106 单轴点动",
    keywords: "J2 回正 归零",
    safetyLevel: 3,
    description: "J2轴移动到0度",
    params: { axis_no: 1, pos_val: 0.0 },
    writes: [{ startVr: 0, values: [106.0] }],
  },
  {
    queryKey: "T0延时1秒",
    funcNum: 109,
    funcName: "Func109 延时",
    keywords: "延时 等待 T0",
    safetyLevel: 1,
    description: "延时1000毫秒",
    params: { delay_ms: 1000 },
    writes: [{ startVr: 0, values: [109.0] }],
  },
  {
    queryKey: "急停",
    funcNum: 104,
    funcName: "Func104 停止",
    keywords: "急停 停止 紧急",
    safetyLevel: 10,
    description: "紧急停止所有运动",
    params: {},
    writes: [{ startVr: 0, values: [104.0] }],
  },
  {
    queryKey: "home",
    funcNum: 108,
    funcName: "Func108 直线/PTP",
    keywords: "回零 home 原点",
    safetyLevel: 5,
    description: "移动到原点位置",
    params: { target: "home" },
    writes: [{ startVr: 0, values: [108.0] }],
  },
  {
    queryKey: "位置A",
    funcNum: 108,
    funcName: "Func108 直线/PTP",
    keywords: "位置A 点位A",
    safetyLevel: 5,
    description: "移动到位置A",
    params: { target: "A" },
    writes: [{ startVr: 0, values: [108.0] }],
  },
];

// 模拟日志数据
const MOCK_LOGS: LogEntry[] = [
  {
    id: 1,
    time: "22:28:58.381",
    category: "反馈",
    operation: "实时监控",
    result: "failed",
    detail: "connect(192.168.1.11) failed with code 20008",
  },
  {
    id: 2,
    time: "22:28:57.634",
    category: "连接",
    operation: "检测连接",
    result: "failed",
    detail: "connect(192.168.1.11) failed with code 20008",
  },
  {
    id: 3,
    time: "22:28:57.439",
    category: "语音",
    operation: "刷新麦克风设备",
    result: "success",
    detail: "检测到 16 个输入设备",
  },
  {
    id: 4,
    time: "22:28:57.439",
    category: "语音",
    operation: "预热麦克风",
    result: "success",
    detail: "麦克风流已后台启动",
  },
];

interface RobotContextType {
  // 状态
  snapshot: RobotSnapshot;
  isConnected: boolean;

  // 对话相关
  conversation: ConversationEvent[];
  addMessage: (
    role: "user" | "system" | "assistant",
    text: string,
    eventType?: ConversationEvent["eventType"]
  ) => void;
  clearConversation: () => void;

  // 计划与执行
  currentPlan: ActionPlan | null;
  executionState: ExecutionState | null;
  setPlan: (plan: ActionPlan | null) => void;
  executeAction: () => void;
  cancelAction: () => void;

  // 模板管理
  templates: CommandTemplate[];
  selectedTemplate: CommandTemplate | null;
  selectTemplate: (template: CommandTemplate | null) => void;
  updateTemplate: (template: CommandTemplate) => void;
  addTemplate: (template: CommandTemplate) => void;
  deleteTemplate: (queryKey: string) => void;

  // 日志
  logs: LogEntry[];
  refreshLogs: () => void;
  clearLogs: () => void;
  exportLogs: () => void;

  // 系统控制
  emergencyStop: () => void;
  pauseSystem: () => void;
  resumeSystem: () => void;
  resetAlarm: () => void;
  connectController: (ip: string) => Promise<boolean>;
}

const defaultSnapshot: RobotSnapshot = {
  systemState: "offline",
  connectionState: "offline",
  estop: false,
  pause: false,
  alarmCode: 0,
  alarmText: "",
  currentFunc: 0,
  dpos: [1250.0, 0.0, 860.0, 0.0, 0.0, 0.0],
  mpos: [1250.0, 0.0, 860.0, 0.0, 0.0, 0.0],
  rCurrent: 1250.0,
  zCurrent: 860.0,
  speed: 30,
  taskId: 0,
};

const RobotContext = createContext<RobotContextType | undefined>(undefined);

export function RobotProvider({ children }: { children: ReactNode }) {
  const [snapshot, setSnapshot] = useState<RobotSnapshot>(defaultSnapshot);
  const [conversation, setConversation] = useState<ConversationEvent[]>([]);
  const [currentPlan, setCurrentPlan] = useState<ActionPlan | null>(null);
  const [executionState, setExecutionState] = useState<ExecutionState | null>(
    null
  );
  const [templates, setTemplates] =
    useState<CommandTemplate[]>(MOCK_TEMPLATES);
  const [selectedTemplate, setSelectedTemplate] =
    useState<CommandTemplate | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>(MOCK_LOGS);

  // 模拟状态轮询
  useEffect(() => {
    const interval = setInterval(() => {
      setSnapshot((prev) => ({
        ...prev,
        // 模拟小幅度变化
        dpos: prev.dpos.map((v, i) =>
          i === 0 ? v + (Math.random() - 0.5) * 0.01 : v
        ),
      }));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const addMessage = useCallback(
    (
      role: "user" | "system" | "assistant",
      text: string,
      eventType: ConversationEvent["eventType"] = "input"
    ) => {
      const event: ConversationEvent = {
        eventId: `evt-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
        time: new Date(),
        role,
        eventType,
        text,
      };
      setConversation((prev) => [...prev, event]);
    },
    []
  );

  const clearConversation = useCallback(() => {
    setConversation([]);
  }, []);

  const setPlan = useCallback((plan: ActionPlan | null) => {
    setCurrentPlan(plan);
  }, []);

  const executeAction = useCallback(() => {
    if (!currentPlan) return;

    setExecutionState({
      taskId: Date.now(),
      planId: currentPlan.planId,
      status: "executing",
      progressPct: 0,
      progressIsEstimated: true,
      currentStep: 1,
      totalSteps: 1,
    });

    // 模拟执行过程
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      if (progress >= 100) {
        clearInterval(interval);
        setExecutionState((prev) =>
          prev ? { ...prev, status: "completed", progressPct: 100 } : null
        );
        addMessage("system", "执行完成", "execute");
        setCurrentPlan(null);
      } else {
        setExecutionState((prev) =>
          prev ? { ...prev, progressPct: progress } : null
        );
      }
    }, 200);
  }, [currentPlan, addMessage]);

  const cancelAction = useCallback(() => {
    setCurrentPlan(null);
    setExecutionState(null);
    addMessage("system", "已取消操作", "execute");
  }, [addMessage]);

  const selectTemplate = useCallback((template: CommandTemplate | null) => {
    setSelectedTemplate(template);
  }, []);

  const updateTemplate = useCallback((template: CommandTemplate) => {
    setTemplates((prev) =>
      prev.map((t) => (t.queryKey === template.queryKey ? template : t))
    );
    setSelectedTemplate(template);
  }, []);

  const addTemplate = useCallback((template: CommandTemplate) => {
    setTemplates((prev) => [...prev, template]);
  }, []);

  const deleteTemplate = useCallback((queryKey: string) => {
    setTemplates((prev) => prev.filter((t) => t.queryKey !== queryKey));
    setSelectedTemplate(null);
  }, []);

  const refreshLogs = useCallback(() => {
    // 模拟刷新日志
    const newLog: LogEntry = {
      id: logs.length + 1,
      time: new Date().toLocaleTimeString("zh-CN", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }),
      category: "系统",
      operation: "刷新日志",
      result: "success",
      detail: "日志已刷新",
    };
    setLogs((prev) => [newLog, ...prev]);
  }, [logs.length]);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  const exportLogs = useCallback(() => {
    const logText = logs
      .map(
        (l) =>
          `${l.time}\t${l.category}\t${l.operation}\t${l.result}\t${l.detail}`
      )
      .join("\n");
    const blob = new Blob([logText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `logs_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }, [logs]);

  const emergencyStop = useCallback(() => {
    setSnapshot((prev) => ({
      ...prev,
      estop: true,
      systemState: "estop",
    }));
    addMessage("system", "紧急停止已触发", "alarm");
  }, [addMessage]);

  const pauseSystem = useCallback(() => {
    setSnapshot((prev) => ({
      ...prev,
      pause: true,
      systemState: "pause",
    }));
    addMessage("system", "系统已暂停", "status");
  }, [addMessage]);

  const resumeSystem = useCallback(() => {
    setSnapshot((prev) => ({
      ...prev,
      pause: false,
      systemState: prev.estop ? "estop" : "idle",
    }));
    addMessage("system", "系统已恢复", "status");
  }, [addMessage]);

  const resetAlarm = useCallback(() => {
    setSnapshot((prev) => ({
      ...prev,
      estop: false,
      alarmCode: 0,
      alarmText: "",
      systemState: "idle",
    }));
    addMessage("system", "报警已复位", "status");
  }, [addMessage]);

  const connectController = useCallback(
    async (ip: string): Promise<boolean> => {
      setSnapshot((prev) => ({
        ...prev,
        connectionState: "connecting",
      }));

      // 模拟连接
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const success = Math.random() > 0.3; // 70% 成功率
      setSnapshot((prev) => ({
        ...prev,
        connectionState: success ? "online" : "offline",
        systemState: success ? "idle" : "offline",
      }));

      if (success) {
        addMessage("system", `已连接到控制器 ${ip}`, "status");
      } else {
        addMessage("system", `连接控制器 ${ip} 失败`, "alarm");
      }

      return success;
    },
    [addMessage]
  );

  return (
    <RobotContext.Provider
      value={{
        snapshot,
        isConnected: snapshot.connectionState === "online",
        conversation,
        addMessage,
        clearConversation,
        currentPlan,
        executionState,
        setPlan,
        executeAction,
        cancelAction,
        templates,
        selectedTemplate,
        selectTemplate,
        updateTemplate,
        addTemplate,
        deleteTemplate,
        logs,
        refreshLogs,
        clearLogs,
        exportLogs,
        emergencyStop,
        pauseSystem,
        resumeSystem,
        resetAlarm,
        connectController,
      }}
    >
      {children}
    </RobotContext.Provider>
  );
}

export function useRobot() {
  const context = useContext(RobotContext);
  if (context === undefined) {
    throw new Error("useRobot must be used within a RobotProvider");
  }
  return context;
}
