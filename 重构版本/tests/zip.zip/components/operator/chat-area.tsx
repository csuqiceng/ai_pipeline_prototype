"use client";

import { useState, useRef, useEffect } from "react";
import { useRobot } from "@/lib/robot-context";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import {
  Mic,
  Send,
  Square,
  Pause,
  Play,
  AlertTriangle,
  X,
  CheckCircle,
  AlertCircle,
  Clock,
  Loader2,
} from "lucide-react";
import type { ConversationEvent, ActionPlan } from "@/lib/types";

export function ChatArea() {
  const {
    conversation,
    addMessage,
    templates,
    currentPlan,
    executionState,
    setPlan,
    executeAction,
    cancelAction,
    emergencyStop,
    pauseSystem,
    resumeSystem,
  } = useRobot();

  const [input, setInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // 自动滚动到底部
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation]);

  const handleSend = () => {
    if (!input.trim()) return;

    // 添加用户消息
    addMessage("user", input, "input");

    // 立即回执
    setTimeout(() => {
      addMessage("system", "收到，正在处理...", "receipt");
    }, 50);

    // 模拟解析
    setTimeout(() => {
      const matchedTemplate = templates.find(
        (t) =>
          input.includes(t.queryKey) ||
          t.keywords.split(" ").some((k) => k && input.includes(k))
      );

      if (matchedTemplate) {
        // 生成计划
        const plan: ActionPlan = {
          planId: `plan-${Date.now()}`,
          source: "rule",
          actionType: "template",
          target: matchedTemplate.queryKey,
          params: matchedTemplate.params,
          safetyLevel:
            matchedTemplate.safetyLevel > 5 ? "confirm" : "normal",
          precheckStatus: "checking",
          confirmRequired: true,
        };
        setPlan(plan);

        addMessage(
          "assistant",
          `已识别指令：${matchedTemplate.funcName}\n目标：${matchedTemplate.description}`,
          "plan"
        );

        // 模拟预检
        setTimeout(() => {
          addMessage(
            "system",
            "安全预检通过：\n- 限位检查：通过\n- 速度检查：通过\n- 空间范围检查：通过",
            "precheck"
          );
          setPlan({
            ...plan,
            precheckStatus: "passed",
          });
        }, 500);
      } else {
        addMessage(
          "assistant",
          "未匹配到指令模板，请尝试使用标准指令格式，例如：\n- 移动到位置A\n- J1到30度\n- 执行流程1",
          "status"
        );
      }
    }, 200);

    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      addMessage("system", "正在录音...", "status");
    } else {
      addMessage("system", "录音结束，正在识别...", "status");
    }
  };

  const renderMessage = (event: ConversationEvent) => {
    const isUser = event.role === "user";
    const isSystem = event.role === "system";

    const getIcon = () => {
      switch (event.eventType) {
        case "receipt":
          return <Clock className="w-4 h-4 text-secondary" />;
        case "precheck":
          return <CheckCircle className="w-4 h-4 text-[#137A3D]" />;
        case "alarm":
          return <AlertCircle className="w-4 h-4 text-destructive" />;
        case "plan":
          return <CheckCircle className="w-4 h-4 text-primary" />;
        default:
          return null;
      }
    };

    return (
      <div
        key={event.eventId}
        className={cn(
          "flex gap-3 p-3",
          isUser ? "justify-end" : "justify-start"
        )}
      >
        <div
          className={cn(
            "max-w-[80%] rounded-lg p-3",
            isUser
              ? "bg-sidebar text-sidebar-foreground"
              : isSystem
              ? "bg-muted text-muted-foreground"
              : "bg-card border border-border text-foreground"
          )}
        >
          {!isUser && (
            <div className="flex items-center gap-2 mb-1">
              {getIcon()}
              <span className="text-xs font-medium">
                {isSystem ? "系统" : "助手"}
              </span>
              <span className="text-xs text-muted-foreground">
                {event.time.toLocaleTimeString("zh-CN", {
                  hour: "2-digit",
                  minute: "2-digit",
                  second: "2-digit",
                })}
              </span>
            </div>
          )}
          <p className="text-sm whitespace-pre-wrap">{event.text}</p>
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col bg-background overflow-hidden">
      {/* 对话区域 */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-2">
          {conversation.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-lg mb-2">机械手自然语言交互系统</p>
              <p className="text-sm">
                您可以通过文字或语音与机械手交互，例如：
              </p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {["移动到位置A", "J1到30度", "回零", "执行流程1"].map(
                  (cmd) => (
                    <Button
                      key={cmd}
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setInput(cmd);
                      }}
                    >
                      {cmd}
                    </Button>
                  )
                )}
              </div>
            </div>
          )}
          {conversation.map(renderMessage)}
        </div>
      </ScrollArea>

      {/* 计划确认卡片 */}
      {currentPlan && currentPlan.precheckStatus === "passed" && (
        <div className="mx-4 mb-4 p-4 bg-card border-2 border-primary rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-medium text-foreground">待确认执行</h4>
            <span
              className={cn(
                "text-xs px-2 py-1 rounded",
                currentPlan.safetyLevel === "confirm"
                  ? "bg-[#A96800]/20 text-[#A96800]"
                  : "bg-[#137A3D]/20 text-[#137A3D]"
              )}
            >
              {currentPlan.safetyLevel === "confirm" ? "需确认" : "普通"}
            </span>
          </div>
          <p className="text-sm text-muted-foreground mb-3">
            目标：{currentPlan.target}
          </p>
          <div className="flex gap-2">
            <Button
              className="flex-1 bg-primary hover:bg-primary/90"
              onClick={executeAction}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              确认执行
            </Button>
            <Button variant="outline" onClick={cancelAction}>
              <X className="w-4 h-4 mr-2" />
              取消
            </Button>
          </div>
        </div>
      )}

      {/* 执行进度 */}
      {executionState && executionState.status === "executing" && (
        <div className="mx-4 mb-4 p-4 bg-secondary/10 border border-secondary rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Loader2 className="w-4 h-4 animate-spin text-secondary" />
            <span className="font-medium text-foreground">执行中</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2 mb-2">
            <div
              className="bg-secondary h-2 rounded-full transition-all"
              style={{ width: `${executionState.progressPct}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground">
            进度：{executionState.progressPct}%
            {executionState.progressIsEstimated && " (估算)"}
          </p>
        </div>
      )}

      {/* 输入区域 */}
      <div className="p-4 bg-card border-t border-border">
        <div className="flex gap-2 mb-3">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="输入指令或问题..."
            className="min-h-[60px] max-h-[120px] resize-none"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant={isRecording ? "destructive" : "outline"}
            onClick={toggleRecording}
            className="flex-1"
          >
            {isRecording ? (
              <>
                <Square className="w-4 h-4 mr-2" />
                停止录音
              </>
            ) : (
              <>
                <Mic className="w-4 h-4 mr-2" />
                语音输入
              </>
            )}
          </Button>
          <Button
            onClick={handleSend}
            disabled={!input.trim()}
            className="flex-1 bg-sidebar hover:bg-sidebar/90 text-sidebar-foreground"
          >
            <Send className="w-4 h-4 mr-2" />
            发送
          </Button>
          <Button
            variant="outline"
            onClick={pauseSystem}
            className="border-[#A96800] text-[#A96800] hover:bg-[#A96800]/10"
          >
            <Pause className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            onClick={resumeSystem}
            className="border-primary text-primary hover:bg-primary/10"
          >
            <Play className="w-4 h-4" />
          </Button>
          <Button
            variant="destructive"
            onClick={emergencyStop}
            className="px-6"
          >
            <AlertTriangle className="w-4 h-4 mr-2" />
            急停
          </Button>
        </div>
      </div>
    </div>
  );
}
