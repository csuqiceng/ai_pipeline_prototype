"use client";

import { useAuth } from "@/lib/auth-context";
import { useRobot } from "@/lib/robot-context";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  Pause,
  Play,
  RotateCcw,
  Power,
  Settings,
  LogOut,
  Users,
  Wrench,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface SystemControlPanelProps {
  onRoleSwitchRequest?: () => void;
}

export function SystemControlPanel({
  onRoleSwitchRequest,
}: SystemControlPanelProps) {
  const { user, logout } = useAuth();
  const { snapshot, emergencyStop, pauseSystem, resumeSystem, resetAlarm } =
    useRobot();

  const getStatusColor = () => {
    switch (snapshot.systemState) {
      case "running":
        return "bg-secondary";
      case "idle":
        return "bg-[#137A3D]";
      case "estop":
      case "alarm":
        return "bg-destructive";
      case "pause":
        return "bg-[#A96800]";
      default:
        return "bg-muted-foreground";
    }
  };

  const getStatusText = () => {
    switch (snapshot.systemState) {
      case "running":
        return "运行中";
      case "idle":
        return "空闲";
      case "estop":
        return "急停";
      case "alarm":
        return "报警";
      case "pause":
        return "暂停";
      default:
        return "离线";
    }
  };

  return (
    <div className="flex flex-col gap-3">
      {/* 报警复位 */}
      <Button
        variant="outline"
        className="h-12 text-base font-medium border-2 border-foreground hover:bg-muted"
        onClick={resetAlarm}
      >
        <RotateCcw className="w-5 h-5 mr-2" />
        报警复位
      </Button>

      {/* 暂停 */}
      <Button
        className="h-12 text-base font-medium bg-[#A96800] hover:bg-[#A96800]/90 text-white"
        onClick={pauseSystem}
        disabled={snapshot.pause}
      >
        <Pause className="w-5 h-5 mr-2" />
        暂停
      </Button>

      {/* 继续 */}
      <Button
        variant="outline"
        className="h-12 text-base font-medium border-2 border-foreground hover:bg-muted"
        onClick={resumeSystem}
        disabled={!snapshot.pause}
      >
        <Play className="w-5 h-5 mr-2" />
        继续
      </Button>

      {/* 急停按钮 - 最重要的按钮 */}
      <Button
        className="h-16 text-lg font-bold bg-destructive hover:bg-destructive/90 text-white shadow-lg"
        onClick={emergencyStop}
      >
        <AlertTriangle className="w-6 h-6 mr-2" />
        急停
      </Button>

      {/* 系统状态 */}
      <div className="mt-4 p-4 bg-card border border-border rounded-lg">
        <p className="text-xs text-muted-foreground mb-2">系统状态</p>
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${getStatusColor()}`} />
          <span className="text-xl font-bold text-foreground">
            {getStatusText()}
          </span>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          {snapshot.connectionState === "online"
            ? "实时监控离线"
            : "未连接或无实时反馈"}
        </p>
      </div>

      {/* 授权按钮 */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="h-12 text-base font-medium border-2 border-foreground hover:bg-muted"
          >
            <Power className="w-5 h-5 mr-2" />
            授权
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <div className="px-2 py-1.5 text-sm font-medium text-foreground">
            {user?.displayName}
          </div>
          <DropdownMenuSeparator />
          {user?.role === "engineer" && onRoleSwitchRequest && (
            <DropdownMenuItem onClick={onRoleSwitchRequest}>
              <Users className="w-4 h-4 mr-2" />
              切换到使用页面
            </DropdownMenuItem>
          )}
          {user?.role === "operator" && onRoleSwitchRequest && (
            <DropdownMenuItem onClick={onRoleSwitchRequest}>
              <Wrench className="w-4 h-4 mr-2" />
              切换到工程师页面
            </DropdownMenuItem>
          )}
          <DropdownMenuItem>
            <Settings className="w-4 h-4 mr-2" />
            系统设置
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={logout} className="text-destructive">
            <LogOut className="w-4 h-4 mr-2" />
            退出登录
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <p className="text-xs text-muted-foreground text-center">
        {snapshot.connectionState === "online" ? "[已授权]" : "[未授权]"}
      </p>
    </div>
  );
}
