"use client";

import { useState } from "react";
import { useRobot } from "@/lib/robot-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Plus,
  Save,
  Copy,
  Trash2,
  Upload,
  Download,
} from "lucide-react";
import type { CommandTemplate } from "@/lib/types";

export function EngineerBackendPage() {
  const {
    templates,
    selectedTemplate,
    selectTemplate,
    updateTemplate,
    addTemplate,
    deleteTemplate,
  } = useRobot();

  const [editingTemplate, setEditingTemplate] =
    useState<CommandTemplate | null>(null);

  // 当选择模板时，复制到编辑状态
  const handleSelectTemplate = (template: CommandTemplate) => {
    selectTemplate(template);
    setEditingTemplate({ ...template });
  };

  const handleFieldChange = (
    field: keyof CommandTemplate,
    value: string | number
  ) => {
    if (!editingTemplate) return;
    setEditingTemplate({
      ...editingTemplate,
      [field]: value,
    });
  };

  const handleParamChange = (key: string, value: string) => {
    if (!editingTemplate) return;
    setEditingTemplate({
      ...editingTemplate,
      params: {
        ...editingTemplate.params,
        [key]: isNaN(Number(value)) ? value : Number(value),
      },
    });
  };

  const handleSave = () => {
    if (!editingTemplate) return;
    updateTemplate(editingTemplate);
  };

  const handleSaveAs = () => {
    if (!editingTemplate) return;
    const newTemplate = {
      ...editingTemplate,
      queryKey: `${editingTemplate.queryKey}_copy`,
    };
    addTemplate(newTemplate);
    selectTemplate(newTemplate);
    setEditingTemplate(newTemplate);
  };

  const handleDelete = () => {
    if (!selectedTemplate) return;
    if (confirm(`确定要删除模板 "${selectedTemplate.queryKey}" 吗？`)) {
      deleteTemplate(selectedTemplate.queryKey);
      setEditingTemplate(null);
    }
  };

  const handleNew = () => {
    const newTemplate: CommandTemplate = {
      queryKey: "新模板",
      funcNum: 100,
      funcName: "新函数",
      keywords: "",
      safetyLevel: 5,
      description: "",
      params: {},
      writes: [],
    };
    addTemplate(newTemplate);
    selectTemplate(newTemplate);
    setEditingTemplate(newTemplate);
  };

  // 生成JSON预览
  const generateJsonPreview = () => {
    if (!editingTemplate) return "";
    return JSON.stringify(
      {
        queryKey: editingTemplate.queryKey,
        funcNum: editingTemplate.funcNum,
        funcName: editingTemplate.funcName,
        keywords: editingTemplate.keywords,
        description: editingTemplate.description,
        safetyLevel: editingTemplate.safetyLevel,
        params: editingTemplate.params,
        writes: editingTemplate.writes,
      },
      null,
      2
    );
  };

  return (
    <div className="flex flex-col h-full gap-4 overflow-hidden">
      {/* 顶部信息区 */}
      <div className="grid grid-cols-3 gap-4">
        {/* 功能说明 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
            功能说明
          </h3>
          <div className="text-xs space-y-1">
            <p>
              <span className="font-medium">用途:</span> 维护函数号与参数模板
            </p>
            <p>
              <span className="font-medium">支持:</span> Func104 停止
            </p>
            <p>
              <span className="font-medium">支持:</span> Func106/107 点动
            </p>
            <p>
              <span className="font-medium">支持:</span> Func108 直线/PTP
            </p>
            <p>
              <span className="font-medium">stop_cmd:</span> 0正常 1急停 2快停
              3慢停 4暂停 5恢复
            </p>
            <p>
              <span className="font-medium">fuzzy:</span> 0绝对 1叠加当前值
            </p>
            <p>
              <span className="font-medium">move_type:</span> 0直线插补 1PTP关节
            </p>
          </div>
        </div>

        {/* 当前选中模板 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
            当前选中模板
          </h3>
          <div className="text-xs space-y-1">
            <p>
              <span className="font-medium">显示名称:</span>{" "}
              {selectedTemplate?.queryKey || "-"}
            </p>
            <p>
              <span className="font-medium">指令码:</span>{" "}
              {selectedTemplate?.funcNum || "-"}
            </p>
            <p>
              <span className="font-medium">指令类型:</span>{" "}
              {selectedTemplate?.funcName || "-"}
            </p>
            <p>
              <span className="font-medium">模板分类:</span> 函数号参数模板
            </p>
            <p>
              <span className="font-medium">参数说明:</span> -
            </p>
          </div>
        </div>

        {/* 后台操作 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
            后台操作
          </h3>
          <div className="grid grid-cols-2 gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={handleNew}
              className="text-xs"
            >
              <Plus className="w-3 h-3 mr-1" />
              新增
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleSave}
              disabled={!editingTemplate}
              className="text-xs"
            >
              <Save className="w-3 h-3 mr-1" />
              保存
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleSaveAs}
              disabled={!editingTemplate}
              className="text-xs"
            >
              <Copy className="w-3 h-3 mr-1" />
              另存为
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleDelete}
              disabled={!selectedTemplate}
              className="text-xs text-destructive hover:text-destructive"
            >
              <Trash2 className="w-3 h-3 mr-1" />
              删除
            </Button>
            <Button size="sm" variant="outline" className="text-xs">
              <Upload className="w-3 h-3 mr-1" />
              导出指令
            </Button>
            <Button size="sm" variant="outline" className="text-xs">
              <Download className="w-3 h-3 mr-1" />
              导入指令
            </Button>
          </div>
        </div>
      </div>

      {/* 主内容区 */}
      <div className="flex-1 grid grid-cols-3 gap-4 overflow-hidden">
        {/* 左侧：模板列表 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card flex flex-col overflow-hidden">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
            指令模板列表
          </h3>
          <ScrollArea className="flex-1">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0">
                <tr>
                  <th className="p-2 text-left font-medium">显示名称</th>
                  <th className="p-2 text-left font-medium">函数号</th>
                </tr>
              </thead>
              <tbody>
                {templates.map((t) => (
                  <tr
                    key={t.queryKey}
                    className={`border-b border-border cursor-pointer hover:bg-muted/50 ${
                      selectedTemplate?.queryKey === t.queryKey
                        ? "bg-sidebar/10"
                        : ""
                    }`}
                    onClick={() => handleSelectTemplate(t)}
                  >
                    <td className="p-2">{t.queryKey}</td>
                    <td className="p-2">Func{t.funcNum}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ScrollArea>
        </div>

        {/* 中间：模板编辑 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card flex flex-col overflow-hidden">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
            模板编辑
          </h3>
          <ScrollArea className="flex-1">
            {editingTemplate ? (
              <div className="space-y-3 pr-2">
                <div className="grid grid-cols-[120px_1fr] items-center gap-2">
                  <Label className="text-xs">显示名称 (query_key):</Label>
                  <Input
                    value={editingTemplate.queryKey}
                    onChange={(e) =>
                      handleFieldChange("queryKey", e.target.value)
                    }
                    className="h-8 text-xs"
                  />
                </div>
                <div className="grid grid-cols-[120px_1fr] items-center gap-2">
                  <Label className="text-xs">函数号 (func_id):</Label>
                  <Select
                    value={`Func${editingTemplate.funcNum}`}
                    onValueChange={(v) =>
                      handleFieldChange("funcNum", parseInt(v.replace("Func", "")))
                    }
                  >
                    <SelectTrigger className="h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Func104">Func104 停止</SelectItem>
                      <SelectItem value="Func106">Func106 单轴点动</SelectItem>
                      <SelectItem value="Func107">Func107 多轴点动</SelectItem>
                      <SelectItem value="Func108">Func108 直线/PTP</SelectItem>
                      <SelectItem value="Func109">Func109 延时</SelectItem>
                      <SelectItem value="Func110">Func110 等待IO</SelectItem>
                      <SelectItem value="Func120">Func120 IO控制</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-[120px_1fr] items-center gap-2">
                  <Label className="text-xs">函数名 (func_name):</Label>
                  <Input
                    value={editingTemplate.funcName}
                    onChange={(e) =>
                      handleFieldChange("funcName", e.target.value)
                    }
                    className="h-8 text-xs"
                  />
                </div>
                <div className="grid grid-cols-[120px_1fr] items-center gap-2">
                  <Label className="text-xs">自然语言关键词:</Label>
                  <Input
                    value={editingTemplate.keywords}
                    onChange={(e) =>
                      handleFieldChange("keywords", e.target.value)
                    }
                    className="h-8 text-xs"
                    placeholder="多个关键词用空格分隔"
                  />
                </div>
                <div className="grid grid-cols-[120px_1fr] items-center gap-2">
                  <Label className="text-xs">安全等级 (safety_level):</Label>
                  <Input
                    type="number"
                    value={editingTemplate.safetyLevel}
                    onChange={(e) =>
                      handleFieldChange("safetyLevel", parseInt(e.target.value))
                    }
                    className="h-8 text-xs"
                    min={1}
                    max={10}
                  />
                </div>
                <div className="grid grid-cols-[120px_1fr] items-center gap-2">
                  <Label className="text-xs">说明 (description):</Label>
                  <Textarea
                    value={editingTemplate.description}
                    onChange={(e) =>
                      handleFieldChange("description", e.target.value)
                    }
                    className="text-xs min-h-[60px]"
                  />
                </div>

                {/* 参数编辑 */}
                <div className="pt-2 border-t border-border">
                  <Label className="text-xs font-medium">参数设置</Label>
                  {Object.entries(editingTemplate.params).map(([key, value]) => (
                    <div
                      key={key}
                      className="grid grid-cols-[120px_1fr] items-center gap-2 mt-2"
                    >
                      <Label className="text-xs">{key}:</Label>
                      <Input
                        value={String(value)}
                        onChange={(e) => handleParamChange(key, e.target.value)}
                        className="h-8 text-xs"
                      />
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                请选择或新增模板
              </div>
            )}
          </ScrollArea>
        </div>

        {/* 右侧：JSON预览和系统参数 */}
        <div className="flex flex-col gap-4 overflow-hidden">
          <Tabs defaultValue="json" className="flex-1 flex flex-col overflow-hidden">
            <TabsList className="bg-muted w-full justify-start">
              <TabsTrigger value="json" className="text-xs">
                JSON预览
              </TabsTrigger>
              <TabsTrigger value="system" className="text-xs">
                系统参数
              </TabsTrigger>
              <TabsTrigger value="safety" className="text-xs">
                安全中间点
              </TabsTrigger>
              <TabsTrigger value="flow" className="text-xs">
                流程管理
              </TabsTrigger>
            </TabsList>

            <TabsContent value="json" className="flex-1 overflow-hidden mt-2">
              <div className="h-full p-4 border-2 border-sidebar rounded-lg bg-card flex flex-col overflow-hidden">
                <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
                  结构化 JSON 预览
                </h3>
                <ScrollArea className="flex-1">
                  <pre className="text-xs font-mono whitespace-pre-wrap">
                    {generateJsonPreview() || "选择模板以预览JSON"}
                  </pre>
                </ScrollArea>
              </div>
            </TabsContent>

            <TabsContent value="system" className="flex-1 overflow-hidden mt-2">
              <div className="h-full p-4 border-2 border-sidebar rounded-lg bg-card overflow-auto">
                <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
                  系统参数
                </h3>
                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <Label>运动范围 R_min:</Label>
                    <Input defaultValue="200" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>运动范围 R_max:</Label>
                    <Input defaultValue="1500" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>安全半径:</Label>
                    <Input defaultValue="800" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>安全高度 Z_min:</Label>
                    <Input defaultValue="100" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>安全高度 Z_max:</Label>
                    <Input defaultValue="1200" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>最大速度 %:</Label>
                    <Input defaultValue="80" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>最大加速度 %:</Label>
                    <Input defaultValue="100" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>超时时间 (ms):</Label>
                    <Input defaultValue="30000" className="h-7 text-xs" />
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="safety" className="flex-1 overflow-hidden mt-2">
              <div className="h-full p-4 border-2 border-sidebar rounded-lg bg-card overflow-auto">
                <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
                  安全中间点设置
                </h3>
                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <Label>规避模式:</Label>
                    <Select defaultValue="auto">
                      <SelectTrigger className="h-7 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="auto">自动规避</SelectItem>
                        <SelectItem value="manual">手动指定</SelectItem>
                        <SelectItem value="none">不启用</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>触发阈值 R:</Label>
                    <Input defaultValue="300" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>中间点1 X:</Label>
                    <Input defaultValue="500" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>中间点1 Y:</Label>
                    <Input defaultValue="0" className="h-7 text-xs" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Label>中间点1 Z:</Label>
                    <Input defaultValue="600" className="h-7 text-xs" />
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="flow" className="flex-1 overflow-hidden mt-2">
              <div className="h-full p-4 border-2 border-sidebar rounded-lg bg-card overflow-auto">
                <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
                  流程管理
                </h3>
                <div className="space-y-2">
                  <Select defaultValue="flow1">
                    <SelectTrigger className="text-xs">
                      <SelectValue placeholder="选择流程" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="flow1">流程1: 初始化</SelectItem>
                      <SelectItem value="flow2">流程2: 取料</SelectItem>
                      <SelectItem value="flow3">流程3: 放料</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="p-2 bg-muted rounded text-xs">
                    <p className="font-medium mb-1">流程步骤:</p>
                    <ol className="list-decimal list-inside space-y-1">
                      <li>回零 (home)</li>
                      <li>移动到位置A</li>
                      <li>延时1秒</li>
                      <li>夹爪打开</li>
                    </ol>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1 text-xs">
                      添加步骤
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 text-xs">
                      删除步骤
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
