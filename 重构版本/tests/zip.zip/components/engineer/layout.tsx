"use client";

import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { EngineerRunPage } from "./run-page";
import { EngineerBackendPage } from "./backend-page";
import { EngineerLogPage } from "./log-page";
import { SystemControlPanel } from "@/components/system-control-panel";
import { cn } from "@/lib/utils";

type EngineerTab = "run" | "backend" | "log";

interface EngineerLayoutProps {
  onSwitchToOperator?: () => void;
}

export function EngineerLayout({ onSwitchToOperator }: EngineerLayoutProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<EngineerTab>("run");

  const tabs: { id: EngineerTab; label: string }[] = [
    { id: "run", label: "运行" },
    { id: "backend", label: "后台" },
    { id: "log", label: "日志" },
  ];

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* 顶部状态栏 */}
      <header className="h-8 bg-sidebar text-sidebar-foreground flex items-center px-4 text-xs">
        <span>系统就绪 | 数据源: C:\Users\a\Desktop\ai_pipeline_prototype\重构版本\data\query_table.json</span>
        <span className="ml-auto">{user?.displayName}</span>
      </header>

      {/* 主内容区 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧导航 */}
        <nav className="w-20 bg-sidebar flex flex-col">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "h-20 flex items-center justify-center text-lg font-bold transition-colors",
                activeTab === tab.id
                  ? "bg-sidebar-accent text-sidebar-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50"
              )}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {/* 中间内容区 */}
        <main className="flex-1 p-4 overflow-hidden">
          {activeTab === "run" && <EngineerRunPage />}
          {activeTab === "backend" && <EngineerBackendPage />}
          {activeTab === "log" && <EngineerLogPage />}
        </main>

        {/* 右侧控制面板 */}
        <aside className="w-40 p-3 bg-background border-l border-border">
          <SystemControlPanel onRoleSwitchRequest={onSwitchToOperator} />
        </aside>
      </div>
    </div>
  );
}
