"use client";

import { useRobot } from "@/lib/robot-context";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import {
  Activity,
  Shield,
  Gauge,
  Wifi,
  AlertTriangle,
  CheckCircle,
} from "lucide-react";

export function SidePanel() {
  const { snapshot, executionState, isConnected, conversation } = useRobot();

  // 获取最近的事件
  const recentEvents = conversation.slice(-5).reverse();

  return (
    <div className="w-72 bg-card border-l border-border flex flex-col overflow-hidden">
      {/* 待确认计划 */}
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
          <Activity className="w-4 h-4 text-primary" />
          执行状态
        </h3>
        {executionState ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">任务ID:</span>
              <span className="font-mono">{executionState.taskId}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">状态:</span>
              <span
                className={cn(
                  "font-medium",
                  executionState.status === "completed"
                    ? "text-[#137A3D]"
                    : executionState.status === "executing"
                    ? "text-secondary"
                    : "text-muted-foreground"
                )}
              >
                {executionState.status === "completed"
                  ? "完成"
                  : executionState.status === "executing"
                  ? "执行中"
                  : "等待"}
              </span>
            </div>
            <Progress value={executionState.progressPct} className="h-2" />
          </div>
        ) : (
          <p className="text-xs text-muted-foreground">暂无执行任务</p>
        )}
      </div>

      {/* 七类看板摘要 */}
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4 text-primary" />
          安全状态
        </h3>
        <div className="space-y-2">
          <StatusRow
            label="设备状态"
            value={isConnected ? "在线" : "离线"}
            status={isConnected ? "ok" : "error"}
          />
          <StatusRow
            label="急停"
            value={snapshot.estop ? "触发" : "正常"}
            status={snapshot.estop ? "error" : "ok"}
          />
          <StatusRow
            label="暂停"
            value={snapshot.pause ? "暂停中" : "正常"}
            status={snapshot.pause ? "warning" : "ok"}
          />
          <StatusRow
            label="报警"
            value={snapshot.alarmCode > 0 ? `ERR_${snapshot.alarmCode}` : "无"}
            status={snapshot.alarmCode > 0 ? "error" : "ok"}
          />
        </div>
      </div>

      {/* 运动参数 */}
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
          <Gauge className="w-4 h-4 text-primary" />
          运动参数
        </h3>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">当前速度:</span>
            <span className="font-mono">{snapshot.speed}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">R (半径):</span>
            <span className="font-mono">{snapshot.rCurrent.toFixed(1)} mm</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Z (高度):</span>
            <span className="font-mono">{snapshot.zCurrent.toFixed(1)} mm</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">任务ID:</span>
            <span className="font-mono">{snapshot.taskId || "-"}</span>
          </div>
        </div>
      </div>

      {/* 通讯状态 */}
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
          <Wifi className="w-4 h-4 text-primary" />
          通讯状态
        </h3>
        <div className="space-y-2">
          <StatusRow
            label="控制器"
            value={
              snapshot.connectionState === "online"
                ? "已连接"
                : snapshot.connectionState === "connecting"
                ? "连接中"
                : "离线"
            }
            status={
              snapshot.connectionState === "online"
                ? "ok"
                : snapshot.connectionState === "connecting"
                ? "warning"
                : "error"
            }
          />
          <StatusRow label="EtherCAT" value="正常" status="ok" />
          <StatusRow label="实时反馈" value={isConnected ? "正常" : "异常"} status={isConnected ? "ok" : "error"} />
        </div>
      </div>

      {/* 最近事件 */}
      <div className="flex-1 p-4 overflow-hidden flex flex-col">
        <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
          <Activity className="w-4 h-4 text-primary" />
          最近事件
        </h3>
        <ScrollArea className="flex-1">
          <div className="space-y-2">
            {recentEvents.length > 0 ? (
              recentEvents.map((event) => (
                <div
                  key={event.eventId}
                  className="p-2 bg-muted rounded text-xs"
                >
                  <div className="flex items-center gap-1 text-muted-foreground mb-1">
                    <span>
                      {event.time.toLocaleTimeString("zh-CN", {
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit",
                      })}
                    </span>
                    <span>-</span>
                    <span>
                      {event.role === "user"
                        ? "用户"
                        : event.role === "system"
                        ? "系统"
                        : "助手"}
                    </span>
                  </div>
                  <p className="text-foreground line-clamp-2">{event.text}</p>
                </div>
              ))
            ) : (
              <p className="text-xs text-muted-foreground">暂无事件</p>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}

function StatusRow({
  label,
  value,
  status,
}: {
  label: string;
  value: string;
  status: "ok" | "warning" | "error";
}) {
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-muted-foreground">{label}</span>
      <div className="flex items-center gap-1.5">
        {status === "ok" && <CheckCircle className="w-3 h-3 text-[#137A3D]" />}
        {status === "warning" && (
          <AlertTriangle className="w-3 h-3 text-[#A96800]" />
        )}
        {status === "error" && (
          <AlertTriangle className="w-3 h-3 text-destructive" />
        )}
        <span
          className={cn(
            "font-medium",
            status === "ok" && "text-[#137A3D]",
            status === "warning" && "text-[#A96800]",
            status === "error" && "text-destructive"
          )}
        >
          {value}
        </span>
      </div>
    </div>
  );
}
