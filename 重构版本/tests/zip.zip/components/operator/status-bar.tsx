"use client";

import { useRobot } from "@/lib/robot-context";
import { cn } from "@/lib/utils";

export function StatusBar() {
  const { snapshot, isConnected } = useRobot();

  const getOverallStatus = () => {
    if (snapshot.estop) return { label: "急停", color: "bg-destructive" };
    if (snapshot.alarmCode > 0)
      return { label: "报警", color: "bg-destructive" };
    if (snapshot.pause) return { label: "暂停", color: "bg-[#A96800]" };
    if (!isConnected) return { label: "离线", color: "bg-muted-foreground" };
    if (snapshot.systemState === "running")
      return { label: "运行", color: "bg-secondary" };
    return { label: "就绪", color: "bg-[#137A3D]" };
  };

  const status = getOverallStatus();

  const StatusIndicator = ({
    label,
    active,
    color,
  }: {
    label: string;
    active: boolean;
    color: string;
  }) => (
    <div className="flex items-center gap-1.5">
      <div
        className={cn(
          "w-2 h-2 rounded-full",
          active ? color : "bg-muted-foreground/30"
        )}
      />
      <span className="text-xs">{label}</span>
    </div>
  );

  return (
    <div className="h-10 bg-card border-b border-border flex items-center px-4 gap-6 text-foreground">
      {/* 总体状态 */}
      <div className="flex items-center gap-2">
        <div className={cn("w-3 h-3 rounded-full", status.color)} />
        <span className="font-medium text-sm">{status.label}</span>
      </div>

      <div className="h-5 w-px bg-border" />

      {/* 各项状态 */}
      <StatusIndicator
        label="急停"
        active={snapshot.estop}
        color="bg-destructive"
      />
      <StatusIndicator
        label="暂停"
        active={snapshot.pause}
        color="bg-[#A96800]"
      />
      <StatusIndicator
        label="报警"
        active={snapshot.alarmCode > 0}
        color="bg-destructive"
      />
      <StatusIndicator
        label="通讯"
        active={isConnected}
        color="bg-[#137A3D]"
      />

      <div className="h-5 w-px bg-border" />

      {/* 当前执行 */}
      <div className="flex items-center gap-1.5">
        <span className="text-xs text-muted-foreground">当前执行:</span>
        <span className="text-xs font-mono">
          {snapshot.currentFunc > 0 ? `Func${snapshot.currentFunc}` : "空闲"}
        </span>
      </div>

      <div className="h-5 w-px bg-border" />

      {/* 轴位置 */}
      <div className="flex items-center gap-3 text-xs">
        {["J1", "J2", "J3", "J4", "J5", "J6"].map((axis, i) => (
          <div key={axis} className="flex items-center gap-1">
            <span className="text-muted-foreground">{axis}:</span>
            <span className="font-mono w-14 text-right">
              {snapshot.dpos[i]?.toFixed(1)}
            </span>
          </div>
        ))}
      </div>

      <div className="h-5 w-px bg-border" />

      {/* 空间位置 */}
      <div className="flex items-center gap-3 text-xs">
        <div className="flex items-center gap-1">
          <span className="text-muted-foreground">R:</span>
          <span className="font-mono">{snapshot.rCurrent.toFixed(1)}</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-muted-foreground">Z:</span>
          <span className="font-mono">{snapshot.zCurrent.toFixed(1)}</span>
        </div>
      </div>
    </div>
  );
}
