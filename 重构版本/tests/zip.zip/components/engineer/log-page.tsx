"use client";

import { useRobot } from "@/lib/robot-context";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RefreshCw, Download, Trash2 } from "lucide-react";

export function EngineerLogPage() {
  const { logs, refreshLogs, clearLogs, exportLogs } = useRobot();

  const latestTime =
    logs.length > 0 ? logs[0].time : "-";
  const logCount = logs.length;

  return (
    <div className="flex flex-col h-full gap-4 overflow-hidden">
      {/* 顶部信息区 */}
      <div className="grid grid-cols-3 gap-4">
        {/* 日志说明 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
            日志说明
          </h3>
          <div className="text-xs space-y-1">
            <p>
              <span className="font-medium">记录范围:</span> 系统按钮 / 连接检测
            </p>
            <p>
              <span className="font-medium">记录范围:</span> 指令发送 / 反馈读取
            </p>
            <p>
              <span className="font-medium">记录范围:</span> 模板新增 / 保存 /
              删除
            </p>
          </div>
        </div>

        {/* 日志摘要 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
            日志摘要
          </h3>
          <div className="text-xs space-y-1">
            <p>
              <span className="font-medium">日志条数:</span> {logCount}
            </p>
            <p>
              <span className="font-medium">最近时间:</span> {latestTime}
            </p>
          </div>
        </div>

        {/* 日志操作 */}
        <div className="p-4 border-2 border-sidebar rounded-lg bg-card">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
            日志操作
          </h3>
          <div className="space-y-2">
            <Button
              size="sm"
              variant="outline"
              onClick={refreshLogs}
              className="w-full text-xs justify-start"
            >
              <RefreshCw className="w-3 h-3 mr-2" />
              刷新日志
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={exportLogs}
              className="w-full text-xs justify-start"
            >
              <Download className="w-3 h-3 mr-2" />
              导出日志
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                if (confirm("确定要清空所有日志吗？")) {
                  clearLogs();
                }
              }}
              className="w-full text-xs justify-start text-destructive hover:text-destructive"
            >
              <Trash2 className="w-3 h-3 mr-2" />
              清空日志
            </Button>
          </div>
        </div>
      </div>

      {/* 日志表格 */}
      <div className="flex-1 p-4 border-2 border-sidebar rounded-lg bg-card overflow-hidden flex flex-col">
        <h3 className="text-sm font-medium text-muted-foreground mb-2 border-b border-sidebar pb-1">
          操作日志
        </h3>
        <ScrollArea className="flex-1">
          <table className="w-full text-sm">
            <thead className="bg-muted sticky top-0">
              <tr>
                <th className="p-2 text-left font-medium w-10">#</th>
                <th className="p-2 text-left font-medium w-28">时间</th>
                <th className="p-2 text-left font-medium w-20">分类</th>
                <th className="p-2 text-left font-medium w-28">操作</th>
                <th className="p-2 text-left font-medium w-16">结果</th>
                <th className="p-2 text-left font-medium">详情</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log, index) => (
                <tr
                  key={log.id}
                  className={`border-b border-border ${
                    index % 2 === 0 ? "bg-muted/30" : ""
                  }`}
                >
                  <td className="p-2 text-muted-foreground">{index + 1}</td>
                  <td className="p-2 font-mono text-xs">{log.time}</td>
                  <td className="p-2">{log.category}</td>
                  <td className="p-2">{log.operation}</td>
                  <td className="p-2">
                    <span
                      className={
                        log.result === "success"
                          ? "text-[#137A3D]"
                          : "text-destructive"
                      }
                    >
                      {log.result === "success" ? "成功" : "失败"}
                    </span>
                  </td>
                  <td className="p-2 text-muted-foreground text-xs max-w-[400px] truncate">
                    {log.detail}
                  </td>
                </tr>
              ))}
              {logs.length === 0 && (
                <tr>
                  <td
                    colSpan={6}
                    className="p-8 text-center text-muted-foreground"
                  >
                    暂无日志记录
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </ScrollArea>
      </div>
    </div>
  );
}
